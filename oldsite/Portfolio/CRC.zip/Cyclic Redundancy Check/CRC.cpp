//#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <math.h> 

using namespace std;

/*************************************************************************
*
*	This program simulates a Layer 2 data transmission. 
*	It's purposes is to implement a Cyclic Redundancy Check in C++
*	This program simulates a transmission both with and without errors
*
*	Note: For proper formatting of code comments (which may be very helpful below)
*	      This program is best viewed using gvim or notepad++.
*
*	See http://en.wikipedia.org/wiki/Cyclic_redundancy_check for more information about CRCs
*
*	Compiled for Windows using Visual Studio 2003
*
*************************************************************************/

struct frame{
	unsigned char data[265];
	unsigned long long int divisor;
	int divisorLength; //polynomial length in bits;
};

void transportLayer(frame &packet, const char fromArray[])
{
	int header;
	int index = 2;

	while(fromArray[index - 2] != '\0')
	{
		packet.data[index] = fromArray[index - 2];
		index++;
	}
														//
	header = ((index) * 8) + packet.divisorLength -1;	//
	packet.data[1] = header & 255;						//calculates and stores length of packet
	header >>= 8;										//
	packet.data[0] = header & 255;						//
}

void calculateCRC(frame &packet)
{
	int byteIndex = 0; //points to the currently selected byte within an array
	int bitIndex; // points to the currently selected bit within a byte in the array
	int index; //points to any given bit within an array; independand of bit and byte Index.
	unsigned long long int carry;
	int header;

	header |= packet.data[0];
	header <<= 8;
	header |= packet.data[1]; //the first two bytes of data contain the length of the packet in bits

	bitIndex = packet.divisorLength;
	
	while(bitIndex) //loads the initial state 
	{
		if(bitIndex > 7) //bitIndex is currently ovloaded in order to load the initial data.
		{
			carry <<= 8;
			carry |= packet.data[byteIndex];
			byteIndex++;
			bitIndex -= 8;
		}
		else if(bitIndex > 0)
		{
			carry <<= bitIndex;
			bitIndex = 8 - bitIndex;
			carry = carry | ( packet.data[byteIndex] >> bitIndex);
			break; //bit index is now ready and marks the approperate bit.  It should never again go over 8 bits.
		}
	}

	if (bitIndex == 0) //initialize loop
		bitIndex = 8;

	if (carry & packet.divisor & unsigned long long int(pow(2, packet.divisorLength - 1))) //XOR primed carry variable with 0 or CRC respectively (see conditional below)
		carry ^= packet.divisor;

	for(index = packet.divisorLength; index < header; index++)
	{
	
		carry <<= 1;													//
		carry = carry | (1 & packet.data[byteIndex] >> bitIndex - 1);	//Bring down digit
		bitIndex--;														//

		if (carry & packet.divisor & int(pow(2, packet.divisorLength - 1))) //IF carry AND 2^(divisorLength - 1) = true THEN
			carry ^= packet.divisor;										//	carry XOR CRC (polynomial)
																			//ElSE
																			//	carry XOR 0
		
		if (bitIndex == 0)	// moves to next byte and resets bitIndex to point to the first bit.
		{
			bitIndex = 8;
			byteIndex++;
		}
	}

	index = packet.divisorLength - 1;
	
	packet.data[byteIndex] = (carry << (8 - (index - (8 * int(index/8))))) & 255; //loads lower part of CRC into last byte which may not use up all space if not a neat number
	
	bitIndex = (index - (8 * int(index/8)));	//
	index -= bitIndex;							//
	carry >>= bitIndex;							//Cleans up positioning so that we have clean breaks 
	byteIndex--;								//

	for (index; index > 0; index -= 8, byteIndex--)
	{
		packet.data[byteIndex] = carry & 255; //Remember 255 = 11111111 in binary
		carry >>= 8;
	}	
}

bool checkCRC(const frame packet)
{
	int byteIndex = 0; //points to the currently selected byte within an array
	int bitIndex; // points to the currently selected bit within a byte in the array
	int index; //points to any given bit within an array; independand of bit and byte Index.
	unsigned long long int carry;
	int header;

	header |= packet.data[0];
	header <<= 8;
	header |= packet.data[1]; //the first two bytes of data contain the length of the packet in bits

	bitIndex = packet.divisorLength;
	
	while(bitIndex) //loads the initial state 
	{
		if(bitIndex > 7) //bitIndex is currently ovloaded in order to load the initial data.
		{
			carry <<= 8;
			carry |= packet.data[byteIndex];
			byteIndex++;
			bitIndex -= 8;
		}
		else if(bitIndex > 0)
		{
			carry <<= bitIndex;
			bitIndex = 8 - bitIndex;
			carry = carry | ( packet.data[byteIndex] >> bitIndex);
			break; //bit index is now ready and marks the approperate bit.  It should never again go over 8 bits.
		}
	}

	if (bitIndex == 0) //initialize loop
		bitIndex = 8;

	if (carry & packet.divisor & unsigned long long int(pow(2, packet.divisorLength - 1))) //XOR primed carry variable with 0 or CRC respectively (see conditional below)
		carry ^= packet.divisor;

	for(index = packet.divisorLength; index < header; index++)
	{
	
		carry <<= 1;													//
		carry = carry | (1 & packet.data[byteIndex] >> bitIndex - 1);	//Bring down digit
		bitIndex--;														//

		if (carry & packet.divisor & int(pow(2, packet.divisorLength - 1))) //IF carry AND 2^(divisorLength - 1) = true THEN
			carry ^= packet.divisor;										//	carry XOR CRC (polynomial)
																			//ElSE
																			//	carry XOR 0
		
		if (bitIndex == 0)	// moves to next byte and resets bitIndex to point to the first bit.
		{
			bitIndex = 8;
			byteIndex++;
		}
	}

	return !carry;
}
/*
Example:

		   The answer doesn't matter and no one cares
		  _________________
10100101 |1001111001001011 0000000 <- padding. These extra zeros are one less than the divisor. This is where we will append the crc.
		  10100101|||||||| ||||||||
				  |||||||| ||||||||
		   01110110||||||| ||||||||
		   00000000||||||| ||||||||
				   ||||||| ||||||||
			11101101|||||| ||||||||
			10100101|||||| ||||||||
				    |||||| ||||||||
			 10010010||||| ||||||||
			 10100101||||| ||||||||
					 ||||| ||||||||
			  01101110|||| ||||||||
			  00000000|||| ||||||||
					  |||| ||||||||
			   11011101||| ||||||||
			   10100101||| ||||||||
					   ||| ||||||||
			    11111000|| ||||||||
				10100101|| ||||||||
						|| ||||||||
				 10111011| ||||||||
				 10100101| ||||||||
						 | ||||||||
				  00111101 ||||||||
				  00000000 ||||||||
						   ||||||||
				   0111101 0|||||||
				   0000000 0|||||||
						    |||||||
				    111101 00||||||
					101001 01||||||
						     ||||||
					 10100 010|||||
					 10100 101|||||
							  |||||
					  0000 1010||||
					  0000 0000||||
							   ||||
					   000 10100|||
					   000 00000|||
								|||
						00 101000||
						00 000000||
								 ||
						 0 1010000|
						 0 0000000|
								  |
						   10100000
						   10100101
						    
							0000101	<- replace the zeros with this value and repeat the divison. If the result is 0, the message is verified.
*/

modify(frame &packet) //randomly select a byte and bit and xor it in order to change its' value
{
	int index = 2;

	while(packet.data[index] != '\0')
		index++;

	int byteIndex = (rand() % index);
	int bitIndex = (rand() % 8);

	packet.data[byteIndex] ^= int(pow(2, bitIndex - 1));
}

int main(void)
{
	frame packet;

	int input;
	int index;
	char random;

	cout << "Enter the powers of the divisor for your CRC. Eg X^7 + X^3 + X^1 + X^0 becomes 7 3 1 0" << endl;
	
	cin >> input;
	packet.divisorLength = input + 1; //store divisor length
	packet.divisor |= int(pow(2, input)); //add first coefficient

	while(cin >> input)								//generate the divisor. Turns on the bit corresponding to the coefficient
	{												//Example:
		packet.divisor |= int(pow(2, input));		//	"X^7 + X^3 + X^1 + 1" AKA "X^7 + X^3 + X^1 + X^0" input as "7 3 1 0"
	}												//Becomes:
													//	 10001011
	cin.clear();
	cin.ignore(10000, '\n');

	transportLayer(packet, "Hi" /*"Welcome to The CRC Pitstop. The purpose of this web is to act as a repository for information on CRC and other checking algorithms. This web contains all kinds of information on CRC algorithms ranging from a paper explaining in detail how they work, to algo\0"*/);

	calculateCRC(packet);

	printf("%x ", packet.data[0]);
	printf("%x ", packet.data[1]);

    for(index = 2; packet.data[index] != '\0'; index++)
  		printf("%x ", packet.data[index]);
	
	cout << endl << endl << "Do you wish to randomly modify the data?" << endl; 

	cin >> random;

	if (random == 'y')
		modify(packet);

	printf("%x ", packet.data[0]);
	printf("%x ", packet.data[1]);
	
    for(index = 2; packet.data[index] != '\0'; index++)
  		printf("%x ", packet.data[index]);

	cout << endl << "Verifying data integrety... " << endl ;
	
	if(checkCRC(packet))
		cout << endl << endl << "SUCCESS" << endl;
	else
		cout << endl << endl << "FAIL" << endl;

	system("pause");

return 0;
}
