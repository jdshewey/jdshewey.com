#include "ImageCheck.au3"

const $c24RGBFullMatch=1 ;Load as 24 bits and full match
const $c24RGBPartialMatch=2 ;Load as 24 bits and partial match
const $c16RGBFullMatch=3 ;Load as 16 bits and full match
const $c16RGBPartialMatch=4 ;Load as 16 bits and partial match

MsgBox(0, "Return Value", findBMP(@ScriptDir & "\ControlImages\StartTrade.bmp", @ScriptDir & "\StartTradeCheck.bmp", $c24RGBFullMatch))

