;$AllWindows = WinList()
;
;For $i = 1 To $AllWindows[0][0]
;   MsgBox(0, "Windows", $AllWindows[$i][0])
;Next

#include <Array.au3>

AutoItSetOption("WinTitleMatchMode", 4)

Dim $array[1]
$iCounter = 1
While 1
If Not WinExists ( "[CLASS:HwndWrapper; INSTANCE:" & $iCounter & "]" ) Then ExitLoop
ReDim $array[$iCounter]
$array[$iCounter-1] = WinGetTitle ( "[CLASS:IEFrame; INSTANCE:" & $iCounter & "]" )
$iCounter += 1
WEnd
_ArrayDisplay ( $array )
Exit

$array2 = WinGetPos($array[0])
_ArrayDisplay ( $array2 )