*	Included in this Zip file  is a header provides a "rational" class which gives support for rational numbers (fractions.)
*	This data type stores a value as a fraction, rather than a decimal number. In other words, this
*	class stores a number as the relationship of a numerator to a denominator. Any calculations are
*	always performed on the numerator and the denominator. This keeps them separate so as to preserve 
*	high numerical precision and cut down on computer error. This allows you to store and operate on 
*	numbers such as 1/10 which cannot be represented in binary without having to worry about situations
*	where strange results occur when dealing with extremely precise situations and/or extremely small decimals.
*
*	Also included in this zip file are an exe and a file, "driver.cpp". "Driver.cpp" is meant to be just that - a driver.
*	Therefore it is not well documented and does not represent a very high quality or neat example of a complete program
*	The point here is to focus on the library. It is well documented, flexible and a good example of the high quality of
*	code that I create. The driver is simply provided as a quick and dirty example of how to use the library and 
* 	as a way to test the library without having to code out some elaborate program to go with the library. The exe
*	is simply a compiled version of the driver + header library. It probably won't make much sense if you don't review
*	the source code of the driver.
*
*	The following data types are supported:
*
*	-Rational
*	-int
*	-long int
*	-__int64
*	-float
*	-double
*	-long double
*
*	The following operations are supported on all of the above (have been overloaded):
*	-Addition
*	-Subtraction
*	-Multiplication
*	-Division
*	-All operation assignment operations (+=,-=,*=,/=)
*	-Boolean comparison operations
*	-Assignment Operator
*
*	In each case, if the right hand term is not a Rational type, it will be coerced to a rational data type;
*
*	For your convenience, the following functions are also provided:
*	-class.numerator() - Returns the numerator as an integer
*	-class.denominator - Returns the denominator as an integer
*	-class.print() - Outputs the fraction to the screen in fractional format
*	-class.printf() - Outputs the fraction the screen as a decimal number
*
*	This class also supports ostream and istream types which easily allows you to load data
*	into Rational types using keyboard or file input and output (via the fstream and iostream libraries)
*	Examples:
*	
*	Rational fraction;
*	cin >> fraction;
*	cout << fraction << endl;
*	
*	One important thing to note: Because you cannot initialize a fraction using the = sign due to limitations 
*	in the C++ compiler, you must initialize using the class constructor function. 
*	Example:
*
*	rational fraction(1, 2);  //initializes the fractoin 1/2