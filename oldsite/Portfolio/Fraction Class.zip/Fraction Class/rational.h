/*****************************************************************************************************************
*
*	Copyright 2005 
*	James Shewey
*	Licensed under the Creative Commons Attribution License
*	http://creativecommons.org/licenses/by/3.0/
*
*	This header provides a "rational" class which provides support for rational numbers (fractions.)
*	This data type stores a value as a fraction, rather than a decimal number. In other words, this
*	class stores a number as the relationship of a numerator to a denominator. Any calculations are
*	always performed on the numerator and the denominator. This keeps them separate so as to preserve 
*	high numerical precision and cut down on computer error. This allows you to store and operate on 
*	numbers such as 1/10 which cannot be represented in binary without having to worry about situations
*	where strange results occur when dealing with extremely precise situations and/or extremely small decimals.
*
*	The following data types are supported:
*
*	-Rational
*	-int
*	-long int
*	-__int64
*	-float
*	-double
*	-long double
*
*	The following operations are supported on all of the above (have been overloaded):
*	-Addition
*	-Subtraction
*	-Multiplication
*	-Division
*	-All operation assignment operations (+=,-=,*=,/=)
*	-Boolean comparison operations
*	-Assignment Operator
*
*	In each case, if the right hand term is not a Rational type, it will be coerced to a rational data type;
*
*	For your convenience, the following functions are also provided:
*	-class.numerator() - Returns the numerator as an integer
*	-class.denominator - Returns the denominator as an integer
*	-class.print() - Outputs the fraction to the screen in fractional format
*	-class.printf() - Outputs the fraction the screen as a decimal number
*
*	This class also supports ostream and istream types which easily allows you to load data
*	into Rational types using keyboard or file input and output (via the fstream and iostream libraries)
*	Examples:
*	
*	Rational fraction;
*	cin >> fraction;
*	cout << fraction << endl;
*	
*	One important thing to note: Because you cannot initialize a fraction using the = sign due to limitations 
*	in the C++ compiler, you must initialize using the class constructor function. 
*	Example:
*
*	rational fraction(1, 2);  //initializes the fractoin 1/2
*
***********************************************************************************************************************/

#include <iostream>
#include <assert.h>
#include <string>
#include <sstream>
#include <math.h>


class Rational
{
private:
	friend std::ostream& operator<<(std::ostream&, const Rational&);
	friend std::istream& operator>>(std::istream&, Rational&);
		
	__int64 gcd(__int64 firstNum, __int64 secondNum)
	
	{
	__int64 numFirst = firstNum;
	__int64 numSecond = secondNum;
	__int64 remainder;
	__int64 numTimes;

	while(1)
	{
		numTimes = __int64(numFirst/numSecond);
		remainder = numFirst % (numSecond * numTimes);

		if (remainder == 0)
			return numSecond;
		if (remainder > numSecond)
			return 1;

		numFirst = numSecond;
		numSecond = remainder;
	}
	}

	Rational floatToRational(long double const convertFrom)
	{
		std::ostringstream convertTo;
		long double rOfDecimal;
		rOfDecimal = convertFrom;
		__int64 lOfDecimal = convertFrom;
		rOfDecimal = rOfDecimal - lOfDecimal;
		convertTo << rOfDecimal;

		Rational returnVal;
		int length;
		returnVal = lOfDecimal;

		length = (convertTo.str()).length();
		if (length != 1)
			length -= 2;
		else
			length = 0;
		
		rOfDecimal = rOfDecimal * pow(10, length);
	
		Rational decimal(rOfDecimal, length * pow(10, length));
		return decimal + lOfDecimal;
	}
	
	__int64 top;
	__int64 bottom;

public:

	Rational operator+(Rational) const;
	Rational operator-(Rational) const;
	Rational operator*(Rational) const;
	Rational operator/(Rational) const;
	bool operator>(Rational) const;
	bool operator<(Rational) const;
	bool operator>=(Rational) const;
	bool operator<=(Rational) const;
	bool operator==(Rational) const;
	bool operator!=(Rational) const;
	void operator+=(Rational);
	void operator-=(Rational);
	void operator*=(Rational);
	void operator/=(Rational);
	
	Rational operator+(__int64);
	Rational operator-(__int64);
	Rational operator*(__int64);
	Rational operator/(__int64);
	bool operator>(__int64);
	bool operator<(__int64);
	bool operator>=(__int64);
	bool operator<=(__int64);
	bool operator==(__int64);
	bool operator!=(__int64);
	void operator+=(__int64);
	void operator-=(__int64);
	void operator*=(__int64);
	void operator/=(__int64);
	Rational operator=(__int64);

	Rational operator+(long int);
	Rational operator-(long int);
	Rational operator*(long int);
	Rational operator/(long int);
	bool operator>(long int);
	bool operator<(long int);
	bool operator>=(long int);
	bool operator<=(long int);
	bool operator==(long int);
	bool operator!=(long int);
	void operator+=(long int);
	void operator-=(long int);
	void operator*=(long int);
	void operator/=(long int);
	Rational operator=(long int);

	Rational operator+(int);
	Rational operator-(int);
	Rational operator*(int);
	Rational operator/(int);
	bool operator>(int);
	bool operator<(int);
	bool operator>=(int);
	bool operator<=(int);
	bool operator==(int);
	bool operator!=(int);
	void operator+=(int);
	void operator-=(int);
	void operator*=(int);
	void operator/=(int);
	Rational operator=(int);

	Rational operator+(long double);
	Rational operator-(long double);
	Rational operator*(long double);
	Rational operator/(long double);
	bool operator>(long double);
	bool operator<(long double) ;
	bool operator>=(long double);
	bool operator<=(long double);
	bool operator==(long double);
	bool operator!=(long double);
	void operator+=(long double);
	void operator-=(long double);
	void operator*=(long double);
	void operator/=(long double);
	Rational operator=(long double);

	Rational operator+(double);
	Rational operator-(double);
	Rational operator*(double);
	Rational operator/(double);
	bool operator>(double);
	bool operator<(double) ;
	bool operator>=(double);
	bool operator<=(double);
	bool operator==(double);
	bool operator!=(double);
	void operator+=(double);
	void operator-=(double);
	void operator*=(double);
	void operator/=(double);
	Rational operator=(double);

	Rational operator+(float);
	Rational operator-(float);
	Rational operator*(float);
	Rational operator/(float);
	bool operator>(float);
	bool operator<(float) ;
	bool operator>=(float);
	bool operator<=(float);
	bool operator==(float);
	bool operator!=(float);
	void operator+=(float);
	void operator-=(float);
	void operator*=(float);
	void operator/=(float);
	Rational operator=(float);
    
	__int64 numerator() const;
	__int64 denominator() const;
	void print() const;
	void printf() const;
	Rational(__int64, __int64);
	Rational();
};

///////////////////////////////////////////////////////////////
// Declarations for operations involving only fraction types //
///////////////////////////////////////////////////////////////

Rational Rational::operator+(Rational B) const
{
	Rational returnVal((top * B.denominator()) + (B.numerator() * bottom), bottom * B.denominator());
	return returnVal;
}
Rational Rational::operator-(Rational B) const
{
	Rational returnVal((top * B.denominator()) - (B.numerator() * bottom), bottom * B.denominator());
	return returnVal;
}
Rational Rational::operator*(Rational B) const
{
	Rational returnVal(top * B.numerator(), bottom * B.denominator());
	return returnVal;
}
Rational Rational::operator/(Rational B) const
{
	Rational returnVal(top * B.denominator(), bottom * B.numerator());
	return returnVal;
}
bool Rational::operator< (Rational B) const
{
	if((long double(top)/(bottom) < (long double(B.numerator())/B.denominator())))
		return true;
	else
		return false;
}
bool Rational::operator> (Rational B) const
{
	if((long double(top)/bottom) > (long double(B.numerator())/B.denominator()))
		return true;
	else
		return false;
}
bool Rational::operator>= (Rational B) const
{
	if((long double(top)/bottom) >= (long double(B.numerator())/B.denominator()))
		return true;
	else
		return false;
}
bool Rational::operator<= (Rational B) const
{
	if((long double(top)/(bottom) <= (long double(B.numerator())/B.denominator())))
		return true;
	else
		return false;
}
bool Rational::operator== (Rational B) const
{
	if((long double(top)/bottom) == (long double(B.numerator())/B.denominator()))
		return true;
	else
		return false;
}
bool Rational::operator!= (Rational B) const
{
	if((long double(top)/bottom) == (long double(B.numerator())/B.denominator()))
		return false;
	else
		return true;
}
void Rational::operator+= (Rational B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (Rational B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (Rational B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (Rational B)
{
Rational returnVal(top, bottom);
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*//////////////////////////////////////////////////////////////////////////////////////////////////////
// Declarations for performing operations involving the coercion of the right hand term of type int64 //
// to a fraction type and then performing operations						      //
//////////////////////////////////////////////////////////////////////////////////////////////////////*/

Rational Rational::operator+(__int64 B)
{
	Rational returnVal(top + (B * bottom), bottom);
	return returnVal;
}
Rational Rational::operator-(__int64 B)
{
	Rational returnVal((top) - (B * bottom), bottom);
	return returnVal;
}
Rational Rational::operator*(__int64 B)
{
	Rational returnVal;
	if (top * B != 0)
	{
		Rational temp(top * B, bottom);
		returnVal = temp;
	}
	return returnVal;
}
Rational Rational::operator/(__int64 B)
{
	Rational returnVal(top, bottom * B);
	assert(returnVal.denominator() != 0); //causes an error if there is division by zero
	return returnVal;
}
bool Rational::operator< (__int64 B)
{
	if((long double(top)/bottom) < B)
		return true;
	else
		return false;
}
bool Rational::operator> (__int64 B)
{
	if((long double(top)/bottom) > B)
		return true;
	else
		return false;
}
bool Rational::operator>= (__int64 B)
{
	if((long double(top)/bottom) >= B)
		return true;
	else
		return false;
}
bool Rational::operator<= (__int64 B)
{
	if((long double(top)/bottom) <= B)
		return true;
	else
		return false;
}
bool Rational::operator== (__int64 B)
{
	if((long double(top)/bottom) == B)
		return true;
	else
		return false;
}
bool Rational::operator!= (__int64 B)
{
	if((long double(top)/bottom) != B)
		return true;
	else
		return false;
}
Rational Rational::operator= (__int64 B)
{
	Rational returnVal;
	if(B == 0)
		;
	else
		Rational returnVal(B, 1);
	return returnVal;
}
void Rational::operator+= (__int64 B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (__int64 B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (__int64 B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (__int64 B)
{
Rational returnVal;
if(top != 0)
{
	Rational temp(top, bottom);
	returnVal = temp;
}
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Declarations for performing operations involving the coercion of the right hand term of type long int //
// to a fraction type ane then performing operations							 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////*/

Rational Rational::operator+(long int B)
{
	Rational returnVal(top + (B * bottom), bottom);
	return returnVal;
}
Rational Rational::operator-(long int B)
{
	Rational returnVal((top) - (B * bottom), bottom);
	return returnVal;
}
Rational Rational::operator*(long int B)
{
	Rational returnVal;
	if (top * B != 0)
	{
		Rational temp(top * B, bottom);
		returnVal = temp;
	}
	return returnVal;
}
Rational Rational::operator/(long int B)
{
	Rational returnVal(top, bottom * B);
	assert(returnVal.denominator() != 0); //causes an error if there is division by zero
	return returnVal;
}
bool Rational::operator< (long int B)
{
	if((long double(top)/bottom) < B)
		return true;
	else
		return false;
}
bool Rational::operator> (long int B)
{
	if((long double(top)/bottom) > B)
		return true;
	else
		return false;
}
bool Rational::operator>= (long int B)
{
	if((long double(top)/bottom) >= B)
		return true;
	else
		return false;
}
bool Rational::operator<= (long int B)
{
	if((long double(top)/bottom) <= B)
		return true;
	else
		return false;
}
bool Rational::operator== (long int B)
{
	if((long double(top)/bottom) == B)
		return true;
	else
		return false;
}
bool Rational::operator!= (long int B)
{
	if((long double(top)/bottom) != B)
		return true;
	else
		return false;
}
Rational Rational::operator= (long int B)
{
	Rational returnVal;
	if(B == 0)
		;
	else
		Rational returnVal(B, 1);
	return returnVal;
}
void Rational::operator+= (long int B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (long int B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (long int B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (long int B)
{
Rational returnVal;
if(top != 0)
{
	Rational temp(top, bottom);
	returnVal = temp;
}
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*////////////////////////////////////////////////////////////////////////////////////////////////////
// Declarations for performing operations involving the coercion of the right hand term of type int //
// to a fraction type ane then performing operations						    //
////////////////////////////////////////////////////////////////////////////////////////////////////*/

Rational Rational::operator+(int B)
{
	Rational returnVal(top + (B * bottom), bottom);
	return returnVal;
}
Rational Rational::operator-(int B)
{
	Rational returnVal((top) - (B * bottom), bottom);
	return returnVal;
}
Rational Rational::operator*(int B)
{
	Rational returnVal;
	if (top * B != 0)
	{
		Rational temp(top * B, bottom);
		returnVal = temp;
	}
	return returnVal;
}
Rational Rational::operator/(int B)
{
	Rational returnVal(top, bottom * B);
	assert(returnVal.denominator() != 0); //causes an error if there is division by zero
	return returnVal;
}
bool Rational::operator< (int B)
{
	if((long double(top)/bottom) < B)
		return true;
	else
		return false;
}
bool Rational::operator> (int B)
{
	if((long double(top)/bottom) > B)
		return true;
	else
		return false;
}
bool Rational::operator>= (int B)
{
	if((long double(top)/bottom) >= B)
		return true;
	else
		return false;
}
bool Rational::operator<= (int B)
{
	if((long double(top)/bottom) <= B)
		return true;
	else
		return false;
}
bool Rational::operator== (int B)
{
	if((long double(top)/bottom) == B)
		return true;
	else
		return false;
}
bool Rational::operator!= (int B)
{
	if((long double(top)/bottom) != B)
		return true;
	else
		return false;
}
Rational Rational::operator= (int B)
{
	Rational returnVal;
	if(B == 0)
		;
	else
		Rational returnVal(B, 1);
	return returnVal;
}
void Rational::operator+= (int B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (int B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (int B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (int B)
{
Rational returnVal;
if(top != 0)
{
	Rational temp(top, bottom);
	returnVal = temp;
}
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Declarations for performing operations involving the coercion of the right hand term of type long double //
// to a fraction type ane then performing operations														//
////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

Rational Rational::operator+(long double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal + tmp;
}
Rational Rational::operator-(long double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal - tmp;
}
Rational Rational::operator*(long double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal * tmp;
}
Rational Rational::operator/(long double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal / tmp;
}
bool Rational::operator< (long double B)
{
	if((long double(top)/bottom) < B)
		return true;
	else
		return false;
}
bool Rational::operator> (long double B)
{
	if((long double(top)/bottom) > B)
		return true;
	else
		return false;
}
bool Rational::operator>= (long double B)
{
	if((long double(top)/bottom) >= B)
		return true;
	else
		return false;
}
bool Rational::operator<= (long double B)
{
	if((long double(top)/bottom) <= B)
		return true;
	else
		return false;
}
bool Rational::operator== (long double B)
{
	if((long double(top)/bottom) == B)
		return true;
	else
		return false;
}
bool Rational::operator!= (long double B)
{
	if((long double(top)/bottom) == B)
		return false;
	else
		return true;
}
Rational Rational::operator= (long double B)
{	
	if(B == 0)
	{
		Rational returnVal;
		return returnVal;
	}
	else
		return floatToRational(B);
}
void Rational::operator+= (long double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (long double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (long double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (long double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*///////////////////////////////////////////////////////////////////////////////////////////////////////
// Declarations for performing operations involving the coercion of the right hand term of type double //
// to a fraction type ane then performing operations						       //
///////////////////////////////////////////////////////////////////////////////////////////////////////*/

Rational Rational::operator+(double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal + tmp;
}
Rational Rational::operator-(double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal - tmp;
}
Rational Rational::operator*(double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal * tmp;
}
Rational Rational::operator/(double B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal / tmp;
}
bool Rational::operator< (double B)
{
	if((long double(top)/bottom) < B)
		return true;
	else
		return false;
}
bool Rational::operator> (double B)
{
	if((long double(top)/bottom) > B)
		return true;
	else
		return false;
}
bool Rational::operator>= (double B)
{
	if((long double(top)/bottom) >= B)
		return true;
	else
		return false;
}
bool Rational::operator<= (double B)
{
	if((long double(top)/bottom) <= B)
		return true;
	else
		return false;
}
bool Rational::operator== (double B)
{
	if((long double(top)/bottom) == B)
		return true;
	else
		return false;
}
bool Rational::operator!= (double B)
{
	if((long double(top)/bottom) == B)
		return false;
	else
		return true;
}
Rational Rational::operator= (double B)
{	
	if(B == 0)
	{
		Rational returnVal;
		return returnVal;
	}
	else
		return floatToRational(B);
}
void Rational::operator+= (double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (double B)
{
Rational returnVal(top, bottom);
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*///////////////////////////////////////////////////////////////////////////////////////////////////////
// Declarations for performing operations involving the coercion of the right hand term of type double //
// to a fraction type ane then performing operations						       //
///////////////////////////////////////////////////////////////////////////////////////////////////////*/

Rational Rational::operator+(float B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal + tmp;
}
Rational Rational::operator-(float B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal - tmp;
}
Rational Rational::operator*(float B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal * tmp;
}
Rational Rational::operator/(float B)
{
	Rational returnVal(top, bottom);
	Rational tmp = floatToRational(B);
	return returnVal / tmp;
}
bool Rational::operator< (float B)
{
	if((long double(top)/bottom) < B)
		return true;
	else
		return false;
}
bool Rational::operator> (float B)
{
	if((long double(top)/bottom) > B)
		return true;
	else
		return false;
}
bool Rational::operator>= (float B)
{
	if((long double(top)/bottom) >= B)
		return true;
	else
		return false;
}
bool Rational::operator<= (float B)
{
	if((long double(top)/bottom) <= B)
		return true;
	else
		return false;
}
bool Rational::operator== (float B)
{
	if((long double(top)/bottom) == B)
		return true;
	else
		return false;
}
bool Rational::operator!= (float B)
{
	if((long double(top)/bottom) == B)
		return false;
	else
		return true;
}
Rational Rational::operator= (float B)
{
	
	if(B == 0)
	{
		Rational returnVal;
		return returnVal;
	}
	else
		return floatToRational(B);
}
void Rational::operator+= (float B)
{
Rational returnVal(top, bottom);
returnVal = returnVal + B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator-= (float B)
{
Rational returnVal(top, bottom);
returnVal = returnVal - B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator*= (float B)
{
Rational returnVal(top, bottom);
returnVal = returnVal * B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}
void Rational::operator/= (float B)
{
Rational returnVal(top, bottom);
returnVal = returnVal / B;
top = returnVal.numerator();
bottom = returnVal.denominator();
}

/*//////////////////////////
// Other member functions //
//////////////////////////*/

__int64 Rational::numerator() const
{
	return top;
}
__int64 Rational::denominator() const
{
	return bottom;
}
void Rational::print() const
{
	std::cout << top << "/" << bottom;
}
void Rational::printf() const
{
	std::cout << long double(top)/bottom;
}
Rational::Rational(__int64 num, __int64 denom)
{
	int GCD;
	if (num == 0)
		GCD = 1;
	else if (num > denom)
		GCD=gcd(num, denom);
	else
		GCD=gcd(denom, num);
	
	top = num/GCD;
	bottom = denom/GCD;	
}
Rational::Rational() //initializes to 0/1 because 0/0 = undefined
{
	top = 0;
	bottom = 1;
}
std::ostream& operator<<(std::ostream &out, const Rational &data)
{
	out << data.numerator() << "/" << data.denominator();
	return out;
}
std::istream& operator>>(std::istream &in, Rational &data)
{
	__int64 num;
	__int64 denom;
	
	in >> num;
	in.ignore(1, '\n');
	in >> denom;
	Rational temp(num, denom);
	data = temp;
return in;
}