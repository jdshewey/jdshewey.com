#include <string>
#include <sstream>
#include "rational.h"
#include <conio.h>
#include <math.h>


using namespace std;

int main()
{
	//rational
	cout << "rational: " << endl << endl;
	Rational A;
	Rational B(1, 2);
	Rational C(1, 4);
	Rational D;
	Rational tmp;
	
	cout << "A: " << A << endl;
	cout << "B: " << B << endl;
	cout << "C: " << C << endl;
	cout << "D: " << D << endl << endl;

	cout << "B+C " << B+C << endl;
	cout << "B-C " << B-C << endl;
	cout << "B*C " << B*C << endl;
	cout << "B/C " << B/C << endl << endl;
	
	cout << "A>B " << (A>B) << endl;
	cout << "A<B " << (A<B) << endl;
	cout << "A>=B " << (A>=B) << endl;
	cout << "A<=B " << (A<=B) << endl;
	cout << "A==B " << (A==B) << endl;
	cout << "A!=B " << (A!=B) << endl << endl;

	cout << endl << "B+=C ";
	B += C;
	B.print();
	cout << endl << "B-=C ";
	B -= C;
	B.print();
	cout << endl << "B*=C ";
	B *= C;
	B.print();
	cout << endl << "B/=C ";
	B /= C;
	B.print();
	cout << endl << endl;	
	
	//int
	cout << "int: " << endl << endl;

	cout << "B+1 " << B+1 << endl;
	cout << "B-1 " << B-1 << endl;
	cout << "B*2 " << B*2 << endl;
	cout << "B/2 " << B/2 << endl << endl;
	
	cout << "A<B " << (A<1) << endl;
	cout << "A>B " << (A>1) << endl;

	D = 2;
	cout << "D: ";
	D.print();	
	
	cout << endl << "D>=2 " << (D>=2) << endl;
	cout << "D<=2 " << (D<=2) << endl;
	cout << "A==B " << (A==1) << endl;
	cout << "A!=B " << (A!=1) << endl;

	cout << endl << "B+=1 ";
	B += 1;
	B.print();
	cout << endl << "B-=1 ";
	B -= 1;
	B.print();
	cout << endl << "B*=2 ";
	B *= 2;
	B.print();
	cout << endl << "B/=2 ";
	B /= 2;
	B.print();
	cout << endl << endl;

	//float

	cout << "float: " << endl << endl;

	cout << "B+.25 " << B+.25 << endl;
	tmp = B-.25;
	cout << "B-.25 " << B-.25 << endl;
	tmp = B*.25;
	cout << "B*.25 " << B*.25 << endl;
	tmp = B/2;
	cout << "B/.25 " << B/.25 << endl << endl;
	

	cout << "A<B " << (A<.25) << endl;
	cout << "A>B " << (A>.25) << endl;

	D = 2;
	cout << "D: ";
	D.print();

	cout << endl << "D>=2 " << (D>=.25) << endl;
	cout << "D<=2 " << (D<=.25) << endl;
	cout << "A==B " << (A==.25) << endl;
	cout << "A!=B " << (A!=.25) << endl;

	cout << endl << "B+=.25 ";
	B += .25;
	B.print();
	cout << endl << "B-=.25 ";
	B -= .25;
	B.print();
	cout << endl << "B*=.25 ";
	B *= .25;
	B.print();
	cout << endl << "B/=.25 ";
	B /= .25;
	B.print();
	cout << endl;

	cout << endl << endl << "enter a fraction: ";
	cin >> D;
	cout << endl << "D is " << D;

	getch();
	return 0;
}