<?php
include "globals.php";

require_once('libs/nusoap.php'); 
$client=new nusoap_client($path);

$input = array('CompanyName'=>$_POST['manufacturer'], 'SerialNumber'=>$_POST['serial'], 'ModelNumber'=>$_POST['model']);


$err = $client->getError();
if ($err) {
        echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
}

$result = $client->call('Lookup', $input);

if ($client->fault) {
        echo '<h2>Fault</h2><pre>';
        print_r($result);
        echo '</pre>';
} else {
        $err = $client->getError();
        if ($err) {
                echo '<h2>Error</h2><pre>' . $err . '</pre>';
        } else {
                echo '<h2>Result</h2><pre>';
                print_r($result);
                echo '</pre>';
        }
}
echo '<h2>Request</h2><pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
echo '<h2>Response</h2><pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->debug_str, ENT_QUOTES) . '</pre>';

#unset($client);
?>
