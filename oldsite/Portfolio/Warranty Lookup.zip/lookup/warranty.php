<?php
#YYYY-MM-DD
// load SOAP library
require_once("libs/nusoap.php");

// set namespace
$ns="http://warranty/webservice/";

// create SOAP server object
$server = new soap_server();

// setup WSDL file, a WSDL file can contain multiple services
$server->configureWSDL('Warranty',$ns);
$server->wsdl->schemaTargetNamespace=$ns;

//http://www.nonplus.net/software/download/geek/books.php was inordinately helpful in programming the SOAP type definitions for this page.

$server->wsdl->addComplexType(
	'Record',
	'complexType',
	'struct',
	'all',
	'',												//StartDate and EndDate would be better as date types, but webmethods sucks and needs these 
	array(												//variable to be a string type to handle null values
		'StartDate' => array('name' => 'StartDate', 'type' => 'xsd:string'), 			//'name' needs to remain 'name'. It cannot be changed or webmethods will choke.
		'EndDate' => array('name' =>	'EndDate', 'type' => 'xsd:string'),			//This also probably meets xml formatting/standards better too
		'WarrantyType' => array('name' => 'WarrantyType', 'type' => 'xsd:string')		//(probably the reason webmethods chokes)
	)
	);

$server->wsdl->addComplexType(
        'Records',
        'complexType',
        'array',
        '',
        'SOAP-ENC:Array',
        array(),
        array(array('ref'=>'SOAP-ENC:arrayType','wsdl:arrayType'=>'tns:Record[]')),
	 'tns:Record');

// register a web service method
$server->register('Lookup',
	array('CompanyName' => 'xsd:string', 'SerialNumber' => 'xsd:string', 'ModelNumber' => 'xsd:string'), 		// input parameters
	array('Warranty' => 'tns:Records', 'IsRegistered' => 'xsd:boolean', 'ShipDate' => 'xsd:string'), 		// output parameter
	$ns, 														// namespace
	"$ns#lookup",		                									// soapaction
	'rpc',                              										// style
	'encoded',                          										// use
	'Looks up warranty information for the device passed to this service'           				// documentation
	);

function lookup($CompanyName, $SerialNumber, $ModelNumber)
{
	$IsRegistered = true;

	if($CompanyName == "Compaq")
	{
		$CompanyName = "Hewlett-Packard";
	}

	switch ($CompanyName)
	{
		case "Dell Inc.":
			# The following block of code provided courtesy of Jared Ballou
                        $ch = curl_init();
                        curl_setopt ($ch, CURLOPT_POST, 2);
                        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); //Sets return value to be string containing contents of url instead of simply "TRUE"
                        curl_setopt ($ch, CURLOPT_COOKIEFILE, "");
                        curl_setopt ($ch, CURLOPT_COOKIE, "OLRProduct=" . $SerialNumber . "|");
                        curl_setopt($ch,  CURLOPT_URL, "http://www.dell.com/support/troubleshooting/us/en/04/TroubleShooting/Display_Warranty_Tab?page=0&perpage=0&name=TroubleShooting_WarrantyTab");
                        $page = curl_exec ($ch);

			//Strip newlines to make parsing work based on string length
                        $newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");

                        $content = str_replace($newlines, "", html_entity_decode($page));
		
			$start = strpos($content,'<div class="CounrtyShipDateLeft">Ship Date:</div><div class="CounrtyShipDateRight">');
			$end = strpos($content,'</div>',$start) + 6;
			$shippingDate = substr($content,$start,$end-$start);

			//Find the beginning of the table that contains warranty data
			$start = strpos($content,'<span>Days Remaining</span></a></th></tr></thead><tbody>');
			$end = strpos($content,'</table>',$start) + 8;
			$table = substr($content,$start,$end-$start);
			preg_match_all("|<tr(.*)</tr>|U",$table,$rows);
			//Sometimes more than 1 warranty is available

#print_r($rows);
$index=0;
			foreach ($rows[0] as $row)
			{
				preg_match_all("|<td(.*)</td>|U",$row,$cells);
				$type = strip_tags($cells[0][0]);
				if(strtotime(strip_tags($cells[0][2])))
				{
					$start = strip_tags($cells[0][2]);
					$end = strip_tags($cells[0][3]);
				}
				else
				{
					$start = strip_tags($cells[0][$StartDateIndex]);
					$end = strip_tags($cells[0][$EndDateIndex]);
				}
#print("start:" . $start);
#print("end: " . $end);
#print("shipping: " . $shippingDate);

				if($end == "")
				{
					$end = "1/1/1990";
				}
				if($start == "")
				{
					$start = "1/1/1990";
				}

				$reformat = explode("/", $end);
				if ((int)$reformat[1] < 10)
				{
					$reformat[1] = "0" . $reformat[1];
				}
				if ((int)$reformat[0] < 10)
				{
					$reformat[0] = "0" . $reformat[0];
				}
                
				$end = $reformat[2] . "-" . $reformat[0] . "-" . $reformat[1];

				$reformat = explode("/", $start);
				if ((int)$reformat[1] < 10)
				{
					$reformat[1] = "0" . $reformat[1];
				}
				if ((int)$reformat[0] < 10)
				{
					$reformat[0] = "0" . $reformat[0];
				}
                
 	 			$start = $reformat[2] . "-" . $reformat[0] . "-" . $reformat[1]; 

				$ShipDate = strip_tags("<" . $shippingDate[3]);
				$Warranty[$index] = array('WarrantyType' => $type, 'StartDate' => $start, 'EndDate' => $end);
				$index++;
			}	

 	       		break;
 	       	case "Hewlett-Packard":

			//Get raw data
			$url = "http://h20000.www2.hp.com/bizsupport/TechSupport/WarrantyResults.jsp?nickname=&sn=" . $SerialNumber . "&country=US&lang=en&printver=true";
			$raw = file_get_contents($url);

			//Strip newlines
			$newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");

			$content = str_replace($newlines, "", html_entity_decode($raw));

			//Warranty table
			$start = strpos($content,'<b><font color=white>Warranty type</font></b>');
			$end = strpos($content,'</table>',$start) + 8;
			$table = substr($content,$start,$end-$start);

			$rows = explode("<[tT][rR].", $table); 
			$rows = preg_split("/<[tT][rR]*>/",$table);

			//Each Care Pack will usually have two sections, collate both

			$index = 2;               
#print_r($rows); 
			foreach ($rows as $row)
			{
				if ($index != 2)
				{
					preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$row,$cells);
#print_r($cells);
					$offset = $index % 2;
#print($offset);
					$WarrantyType = strip_tags($cells[0][0 + $offset]);
					$StartDate = strip_tags($cells[0][1 + $offset]);
					$EndDate = strip_tags($cells[0][2 + $offset]);
		
					if ($StartDate == "")		//Account for single cells without start/end dates
					{
						$StartDate = $LastStart;
					}
					if ($EndDate == "")
					{
						$EndDate = $LastEnd;
					}
					$LastStart = $StartDate;
					$LastEnd = $EndDate;

					if ($StartDate == "")
					{
						$StartDate = '1 Jan 1990';
					}
					if ($EndDate == "")
					{
						$EndDate = '1 Jan 1990';
					}
print($StartDate);
print($EndDate);

					$ShipDate = '1990-01-01';
					$Warranty[$index - 2] = array('WarrantyType' => $WarrantyType, 'StartDate' => date('Y-m-d', strtotime(str_replace(' ', '-', $StartDate))), 'EndDate' => date('Y-m-d', strtotime(str_replace(' ', '-', $EndDate))));
				}
				$index++;

			}
 	       		break;
 	       	case "Apple Computer":
                	$info = file_get_contents("https://selfsolve.apple.com/Warranty.do?serialNumber=" . $SerialNumber . "&country=USA&fullCountryName=UnitedStates");
                	$computer = explode(",", $info);
		        foreach($computer as $row)
		        {
		                $cell = explode("\":\"",$row);
				switch ($cell[0])
				{
					case '"PURCHASE_DATE':
						$ShipDate = substr($cell[1], 0, -1);
						break;
					case '"COV_END_DATE':
						$EndDate = substr($cell[1], 0, -1);
						break;
				}		               
		        }

			if($ShipDate == "")
			{
				$ShipDate = "1990-01-01";
			}	
			if($EndDate == "")
			{
				$EndDate = "1990-01-01";
			}	

			$Warranty[0] = array('WarrantyType' => '', 'StartDate' => '1990-01-01', 'EndDate' => $EndDate);

			break;
		case "IBM/Lenovo":
			$postdata = array(	'sysSerial' => urlencode($SerialNumber),
						'SysMachType' => urlencode(substr($ModelNumber, 0, 4)));

	
			//url-ify the data for the POST 

			foreach($postdata as $key=>$value)
			{ 
				$fields_string .= $key.'='.$value.'&'; 
			} 

			rtrim($fields_string,'&');

		        $ch = curl_init();
		        curl_setopt ($ch, CURLOPT_POST, 2);
			curl_setopt ($ch, CURLOPT_POSTFIELDS, $fields_string);
                        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); //Sets return value to be string containing contents of url instead of simply "TRUE"
                        curl_setopt($ch, CURLOPT_URL, "http://support.lenovo.com/templatedata/Web%20Content/JSP/warrantyLookup.jsp"); //Click service organization in device tree
                        $page = curl_exec ($ch);
#print($page);
			$newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");

			$content = str_replace($newlines, "", html_entity_decode($page));
#print_r($content);
			//Warranty table
			$start = strpos($content,"<img src='http://support.lenovo.com/Resources/Images/c.gif' width='1' height='7' alt='' /></td></tr></table><table width='430' border='0' frame='border' cellspacing='0' cellpadding='0'>");
			$end = strpos($content,"<tr><td width='159'><table width='100%' cellpadding='0' cellspacing='0' border='0'>",$start) + 8;
			$table = substr($content,$start,$end-$start);

			preg_match_all("|<[tT][rR](.*)</[tT][Rr]>|U",$table,$rows);
			preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$rows[0][6],$cells);
#print_r($rows);
			$EndDate = strip_tags($cells[0][2]);

			$WarrantyType = "";

			if($EndDate == "")
			{
				$EndDate = "1990-01-01";
			}

			$ShipDate = '1990-01-01';
			$Warranty[$index] = array('WarrantyType' => $WarrantyType, 'StartDate' => '1990-01-01', 'EndDate' => $EndDate);

			break;
		case "Toshiba":
	
			$postdata = array(	'txtSerialNum' => urlencode($SerialNumber),
						'txtPartNum' => urlencode($ModelNumber));
	
			//url-ify the data for the POST 

			foreach($postdata as $key=>$value)
			{ 
				$fields_string .= $key.'='.$value.'&'; 
			} 

			rtrim($fields_string,'&');

		        $ch = curl_init();
		        curl_setopt ($ch, CURLOPT_POST, 2);
			curl_setopt ($ch, CURLOPT_POSTFIELDS, $fields_string);
                        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); //Sets return value to be string containing contents of url instead of simply "TRUE"
                        curl_setopt($ch, CURLOPT_URL, "http://www.csd.toshiba.com/cgi-bin/tais/support/jsp/globalEntitlement.jsp#SearchResults");
                        $page = curl_exec ($ch);

			//Strip newlines
			$newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");

			$content = str_replace($newlines, "", html_entity_decode($page));

			$start = strpos($content,'Purchase Date:</td><td class="item-list4">');
			$end = strpos($content,'</td></tr>',$start) + 10;
			$table = substr($content,$start,$end-$start);
			$shippingDate = explode('</td>', $table);
			$ShipDate=strip_tags(substr($shippingDate[1], 0, -1));
#print_r($shippingDate);

			//Warranty table

			$start = strpos($content,'<div class="product-info-table"><div class="title-bar margBottom10 small">Product Information</div><table border="0" cellspacing="0" cellpadding="0">');
			$end = strpos($content,'</table>',$start) + 8;
			$table = substr($content,$start,$end-$start);
			preg_match_all("|<[tT][rR](.*)</[tT][Rr]>|U",$table,$rows);

			preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$rows[0][5],$cells);
			$StartDate = strip_tags($cells[0][1]);

			preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$rows[0][8],$cells);
			$EndDate = strip_tags($cells[0][1]);

			preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$rows[0][7],$cells);
			$WarrantyType1 = strip_tags($cells[0][1]);
			preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$rows[0][9],$cells);
			$WarrantyType2 = strip_tags($cells[0][1]);
			preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U",$rows[0][10],$cells);
			$WarrantyType3 = strip_tags($cells[0][1]);

			$WarrantyType = $WarrantyType1. " from " . $WarrantyType2 . " or " . $WarrantyType3;

			$reformat = explode(" ", ereg_replace("[^A-Za-z0-9 ]", "", $ShipDate));	
			$ShipDate = $reformat[1] . "-" . $reformat[0] . "-" . $reformat[2];

			$reformat = explode(" ", ereg_replace("[^A-Za-z0-9 ]", "", $StartDate));	
			$StartDate = $reformat[1] . "-" . $reformat[0] . "-" . $reformat[2];

			$reformat = explode(" ", ereg_replace("[^A-Za-z0-9 ]", "", $EndDate));	
			$EndDate = $reformat[1] . "-" . $reformat[0] . "-" . $reformat[2];
			
			if($StartDate == "")
			{
				$StartDate = "1-Jan-1990";
			}
			if($EndDate == "")
			{
				$EndDate = "1-Jan-1990";
			}

			$ShipDate = date('Y-m-d', strtotime($ShipDate));
			$Warranty[0] = array('WarrantyType' => $WarrantyType, 'StartDate' => date('Y-m-d', strtotime($StartDate)), 'EndDate' => date('Y-m-d', strtotime($EndDate)));
	
			break;
		case "Gateway":
			$url = "http://support.gateway.com/support/srt/warranty.asp?sn=" . $SerialNumber;
			$raw = file_get_contents($url);

			//Strip newlines
			$newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");

			$content = str_replace($newlines, "", html_entity_decode($raw));

			$start = strpos($content,'Ship Date: <b>');
			$end = strpos($content,'</b>',$start) + 4;
			$table = substr($content,$start,$end-$start);
			$shippingDate = explode(' ', $table);
#print_r($shippingDate);
			//Warranty table
			$start = strpos($content,'<table cellpadding="0" cellspacing="0" style="width: 100%; border: 0px"><tr><td><img src="http://cdnsupport.gateway.com/images/ub/ub_clear.gif" width="10" height="1" title="" alt=" "></td><td><img src="http://cdnsupport.gateway.com/images/ub/ub_clear.gif" width="350" height="1" title="" alt=" "></td><td><img src="http://cdnsupport.gateway.com/images/ub/ub_clear.gif" width="10" height="1" title="" alt=" "></td><td><img src="http://cdnsupport.gateway.com/images/ub/ub_clear.gif" width="95" height="1" title="" alt=" "></td><td><img src="http://cdnsupport.gateway.com/images/ub/ub_clear.gif" width="10" height="1" title="" alt=" "></td><td><img src="http://cdnsupport.gateway.com/images/ub/ub_clear.gif" width="100" height="1" title="" alt=" "></td></tr>');
			$end = strpos($content,'</table>',$start) + 8;
			$table = substr($content,$start,$end-$start);
			preg_match_all("|<[tT][rR](.*)</[tT][Rr]>|U",$table,$rows);

			$index = 2;                
			foreach ($rows[0] as $row)
			{
				if ($index > 3 && $index % 2)
				{
					preg_match_all("|<[Tt][Dd](.*)</[Tt][Dd]>|U", $row,$cells);

					$WarrantyType = strip_tags($cells[0][1]);
					$EndDate = strip_tags($cells[0][3]);
					
					if ($EndDate == "Lifetime")
					{
						$EndDate = "1/1/2199";
					}

					$reformat = explode("/", $EndDate);
					if ((int)$reformat[1] < 10)
					{
						$reformat[1] = "0" . $reformat[1];
					}
					if ((int)$reformat[0] < 10)
					{
						$reformat[0] = "0" . $reformat[0];
					}
                
					if ($EndDate == "")
					{
						$EndDate = "1990-01-01";
					}
					else
					{
						$EndDate = $reformat[2] . "-" . $reformat[0] . "-" . $reformat[1];
					}

					$ShipDate = strip_tags($shippingDate[2]);
					$Warranty[($index - 2)/2] = array('WarrantyType' => $WarrantyType, 'StartDate' => '1990-01-01', 'EndDate' => $EndDate);
				}
				$index++;

			}

			break;
		case "American Power Conversion":
print("good");
			$postdata = array(	'serial' => urlencode($SerialNumber),
						'ups_sku' => urlencode($ModelNumber));

	
			//url-ify the data for the POST 

			foreach($postdata as $key=>$value)
			{ 
				$fields_string .= $key.'='.$value.'&'; 
			} 

			rtrim($fields_string,'&');

		        $ch = curl_init();
		        curl_setopt ($ch, CURLOPT_POST, 2);
			curl_setopt ($ch, CURLOPT_POSTFIELDS, $fields_string);
                        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); //Sets return value to be string containing contents of url instead of simply "TRUE"
                        curl_setopt($ch, CURLOPT_URL, "www.apc.com/site/support/index.cfm/warranty-services/ups-factory-warranty-status/index.cfm"); //Click service organization in device tree
                        $page = curl_exec ($ch);

			$newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");

			$content = str_replace($newlines, "", html_entity_decode($page));
print($content);

			//Warranty table
			$start = strpos($content,"comes standard with a <b>");
			$end = strpos($content,"</b> factory warranty. The warranty is effective from the date of purchase.",$start) + 24;
			$WarrantyType = substr($content,$start,$end-$start);

			$WarrantyLength = substr($WarrantyType,0,1);

			$start = strpos($content,"Your product was manufactured on <b>");
			$end = strpos($content," <b>.</div><div class=\"corner4\"></div><div class=\"corner3\"></div><div class=\"corner2\"",$start) + 24;
			$ShipDate = substr($content,$start,$end-$start);

print($WarrantyType);
print($WarrantyLength);
print($ShipDate);
			$Warranty[0] = array('WarrantyType' => $WarrantyType, 'StartDate' => date('Y-m-d', strtotime($StartDate)), 'EndDate' => date('Y-m-d', strtotime($EndDate)));
			break;
		case "Acer":
			break;
	}


#	print_r($Warranty);	
	return array($Warranty, $IsRegistered, $ShipDate);
}

// service the methods 
$HTTP_RAW_POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA'])
                        ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
$server->service($HTTP_RAW_POST_DATA);
?>
