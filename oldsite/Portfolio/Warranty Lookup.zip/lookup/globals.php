<?php
$BASEURL = "http://jdshewey.com/Portfolio";			//Path to driver/php page	
$path = "http://jdshewey.com/Portfolio/warranty.php";		//path to warranty lookup page
$ns = "http://jdshewey.com/Portfolio/";				//Namespace used by NuSooap
$newlines = array("\t","\n","\r","\x20\x20","\0","\x0B");	//Characters which we strip from the data stream

?>
